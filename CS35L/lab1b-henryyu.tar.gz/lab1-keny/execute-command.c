// UCLA CS 111 Lab 1 command execution

#include "command.h"
#include "command-internals.h"

#include <error.h>

/* FIXME: You may need to add #include directives, macro definitions,
   static function definitions, etc.  */
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
   
   
   
   
int
command_status (command_t c)
{
  return c->status;
}

void
execute_command (command_t c, bool time_travel)
{
  /* FIXME: Replace this with your implementation.  You may need to
     add auxiliary functions and otherwise modify the source code.
     You can also use external functions defined in the GNU C Library.  */
  //error (1, 0, "command execution not yet implemented");
  switch(c->type)
  {
	case SIMPLE_COMMAND:
      c->status = -1;
      int std[2];
      int fd[2];
//open file des
      if (c->input != 0)
      {
        if ((fd[0] = open (c->input, O_RDONLY)) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
        if ((std[0] = dup(STDIN_FILENO)) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
        if (dup2 (fd[0], STDIN_FILENO) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
      }
      if (c->output != 0)
      {
        if ((fd[1] = open (c->output, O_WRONLY | O_CREAT | O_TRUNC, 0666)) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
        if ((std[1] = dup(STDOUT_FILENO)) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
        if (dup2 (fd[1], STDOUT_FILENO) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
      }
//fork process
      pid_t pid = fork();
//if fork fails, exit
      if (pid < 0)
      {
        c->status = 1;
        fprintf(stderr, "%s\n", strerror(errno));
        exit(1);
      }
//child process runs execvp
      else if (pid == 0)
      {
        if (execvp (c->u.word[0], c->u.word) == -1)
        {
          c->status = 1;
            fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
      }
//parent process waits on child process
      int status;
      pid = waitpid (pid, &status, 0);      
//parent closes file des
      if (c->input != 0)
      {
        if (close (fd[0]) != 0)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
        if (dup2(std[0], STDIN_FILENO) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
      }
      if (c->output != 0)
      {
        if (close (fd[1]) != 0)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
        if (dup2(std[1], STDOUT_FILENO) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
      }
//parent checks if child succeeded
      if (!WIFEXITED(status) || WEXITSTATUS(status) != 0)
      {
        c->status = 1;
        return;
      }
      c->status = 0;
      return;
	//==========================================================================
    case AND_COMMAND:
      c->status = -1;
      execute_command (c->u.command[0], time_travel);
//if the first command fails, AND also fails
      if (c->u.command[0]->status != 0)
      {
        c->status = 1;
        return;
      }
      execute_command (c->u.command[1], time_travel);
      if (c->u.command[1]->status != 0)
      {
        c->status = 1;
        return;
      }
      c->status = 0;
      return;
//==========================================================================
    case OR_COMMAND:
      c->status = -1;
      execute_command (c->u.command[0], time_travel);
//if the first command succeeds, OR also succeeds
      if (c->u.command[0]->status == 0)
      {
        c->status = 0;
        return;
      }
      execute_command (c->u.command[1], time_travel);
      if (c->u.command[1]->status == 0)
      {
        c->status = 0;
        return;
      }
      c->status = 1;
      return;
//==========================================================================
    case SEQUENCE_COMMAND:
      c->status = -1;
      execute_command (c->u.command[0], time_travel);
      execute_command (c->u.command[1], time_travel);
//SEQUENCE only relies on the second command's status
      if (c->u.command[1]->status != 0)
      {
        c->status = 1;
        return;
      }
      c->status = 0;
      return;
//==========================================================================
    case PIPE_COMMAND:
      c->status = -1;
					// (write_end) | (read_end)
					// pipefd[0] => read
                    // pipefd[1] => write
                    // c->u.command[0] => write
                    // c->u.command[1] => read
      int pipefd[2]; 
      pipe(pipefd); 
      pid_t pid1, pid2;
      pid1 = fork(); 
      if (pid1 < 0)
      {
        c->status = 1;
		fprintf(stderr, "%s\n", strerror(errno));
        exit(1);
      }
//if it is in child
      else if (pid1 == 0)
      { 
        dup2 (pipefd[1], 1); 
//close the read end
        close (pipefd[0]);
        execute_command (c->u.command[0], time_travel); 
//exit automatically close the write end
        exit(0);
      }
//if it is in parent
      else if (pid1 > 0)
      {
        pid2 = fork(); 
        if (pid2 < 0)
        {
          c->status = 1;
		  fprintf(stderr, "%s\n", strerror(errno));
		  exit(1);
        }
//if it is in child again
        else if (pid2 == 0)
        {
          dup2 (pipefd[0], 0); 
          close (pipefd[1]);
          execute_command (c->u.command[1], time_travel); 
//automatically close the read end
          exit(0);
        }
//if everything is successful
        else if (pid2 > 0)
        {
//clean up file descriptors
          close(pipefd[0]); 
          close(pipefd[1]); 
//wait for both process to finish
          int status1, status2; 
          waitpid (pid1, &status1, 0); 
          waitpid (pid2, &status2, 0); 
//set status 
          if (!WIFEXITED(status1) || WEXITSTATUS(status1)!= 0 || 
            !WIFEXITED(status2) || WEXITSTATUS(status2) != 0) 
          {
            c->status = 1; 
  		    fprintf(stderr, "%s\n", strerror(errno));
            exit(1);
          }          
        }
        else
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1); 
        }
      }
      else    
      {
        c->status = 1;
        fprintf(stderr, "%s\n", strerror(errno));
        exit(1);
      }
      c->status = 0;
      return;
//==========================================================================
    case SUBSHELL_COMMAND:
      c->status = -1;
//input output file descriptors
      int iofd[2];

//deal with i/o
      if(c->output != NULL)
      {
        if ((iofd[0] = open (c->output, O_WRONLY | O_CREAT | O_TRUNC, 0666)) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
        if (dup2 (iofd[0], STDOUT_FILENO) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
      }

      if(c->input != NULL)
      {
        if((iofd[1] = open (c->input, O_RDONLY)) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
        if (dup2 (iofd[1], STDIN_FILENO) == -1)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
      }

//recursivly handle the subshell
      execute_command (c->u.subshell_command, time_travel);
//clean up code
      if (c->output != NULL)
        if (close(iofd[0]) != 0)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }
      if(c->input != NULL)
        if (close(iofd[1]) != 0)
        {
          c->status = 1;
          fprintf(stderr, "%s\n", strerror(errno));
          exit(1);
        }

//copy over the status
      c->status = c->u.subshell_command->status; 
      return;
//==========================================================================
    default:
      exit(1);
  }
}
