./bin/dwt3d_ocl $1 $2
