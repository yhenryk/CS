#ifndef CDF97_H
#define CDF97_H

void cdf97(float *x, float *tempbank, int n, int m, int level);

#endif 

