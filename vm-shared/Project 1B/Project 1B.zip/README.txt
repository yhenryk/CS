Name: Henry Yu
UID: 303889334
Email: y.henryk2@gmail.com

I did not work with a partner on this project. I used some of the example html code for the php part. I also used
the links provided in the website to learn and code php to use mysql. 
