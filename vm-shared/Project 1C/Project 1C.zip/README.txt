Name: Henry Yu
UID: 303889334

	I did not partner up with anyone in this project. When adding a Movie,
after sending it, a link comes up that should link the user to a page
that can add a connection between the movie and an actor, supplying
the role. In the sample site, the movie that the user just added is 
selected. However, I could not get this implemented on my project.
	On the Search function, I could not get the order correct. Also
when searching for an actor, it only works with 2 or less words
supplied. Mine does not support more than that many words. I believe
my current implementation will just ignore all words after the first
two for searching for an actor. When searching for a movie, it will
just try to match that phrase.
	Please use the files supplied in this for the load and create sql
files. I believe i did not get the create.sql file correct since
one of my tables was mislabeld as id instead of mid or the other way
around. Also, the Director or Actor or Movie had a line missing from
it to ignore quotes around the inputs. 
